<html>
<body>
	<p>
	<div align="center"><b><h1> Why Dont You Click the Other Button??</h1></b></div> 
</body>
</html>